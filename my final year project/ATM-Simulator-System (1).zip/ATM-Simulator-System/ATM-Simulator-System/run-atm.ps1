$java = (Get-Command java.exe -ErrorAction SilentlyContinue).Source
$javac = (Get-Command javac.exe -ErrorAction SilentlyContinue).Source
$projectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$classes = Join-Path $projectDir "build\classes"
$lib = Join-Path $projectDir "lib"
$h2 = Join-Path $lib "h2-2.2.224.jar"
$jcalendar = Join-Path $lib "jcalendar-1.4.jar"
$log = Join-Path $projectDir "atm.log"

if (!$java -or !(Test-Path $java)) {
    Write-Error "Java was not found on PATH"
    exit 1
}

if (!(Test-Path $h2)) {
    Write-Error "H2 database jar was not found at $h2"
    exit 1
}

if (!(Test-Path $jcalendar)) {
    Write-Error "JCalendar jar was not found at $jcalendar"
    exit 1
}

if ($javac) {
    New-Item -ItemType Directory -Force $classes | Out-Null
    $sources = Get-ChildItem -Path (Join-Path $projectDir "src") -Recurse -Filter *.java | ForEach-Object { $_.FullName }
    & $javac -cp "$lib\*" -d $classes $sources
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Compilation failed"
        exit $LASTEXITCODE
    }
    Copy-Item -Path (Join-Path $projectDir "src\ASimulatorSystem\icons") -Destination (Join-Path $classes "ASimulatorSystem") -Recurse -Force
}

$oldProcesses = Get-CimInstance Win32_Process -Filter "name = 'java.exe'" |
        Where-Object { $_.CommandLine -like "*ASimulatorSystem.*" -or $_.CommandLine -like "*ATM-Simulator-System*" }
foreach ($oldProcess in $oldProcesses) {
    Stop-Process -Id $oldProcess.ProcessId -Force -ErrorAction SilentlyContinue
}

$classpath = "$classes;$h2;$jcalendar"
& $java -cp $classpath ASimulatorSystem.Login 2>&1 | Tee-Object -FilePath $log
